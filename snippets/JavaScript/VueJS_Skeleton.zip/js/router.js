let router = new VueRouter({
    routes: [
        {
            path: "/",
            redirect: "/foo"
        },
        {
            path: "/foo",
            component: fooComponent
        },
        {
            path: "/bar",
            component: barComponent
        },
        {
            path: "/*",
            component: bazComponent
        }
    ]
});
