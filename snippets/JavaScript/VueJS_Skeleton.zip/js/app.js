addEventListener("DOMContentLoaded", function () {
    var app = new Vue({
        el: "#app",
        router: router,
        store: store
    });
});
