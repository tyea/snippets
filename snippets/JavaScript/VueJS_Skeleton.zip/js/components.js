let fooComponent = Vue.component("foo", {
    data: function () {
        return {
            foo: "FOO"
        };
    },
    template: `
        <div>
            <p v-text="foo"></p>
        </div>
    `
});

let barComponent = Vue.component("bar", {
    data: function () {
        return {
            bar: "BAR"
        };
    },
    template: `
        <div>
            <p v-text="bar"></p>
        </div>
    `
});

let bazComponent = Vue.component("baz", {
    data: function () {
        return {
            baz: "BAZ"
        };
    },
    template: `
        <div>
            <p v-text="baz"></p>
        </div>
    `
});
