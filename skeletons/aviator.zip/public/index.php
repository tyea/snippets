<?php

define("__ROOT__", __DIR__ . "/..");
require(__ROOT__ . "/vendor/autoload.php");

$application = new Application();
app()->before([$application, "before"]);
app()->fallback([$application, "fallback"]);
app()->error([$application, "error"]);

app()->route("GET", "/", controller("Default", "index"));
app()->route("GET", "/commands/migrate", controller("Commands", "migrate"));

app()->start();
