<?php

define("__ROOT__", __DIR__ . "/..");
require(__ROOT__ . "/vendor/autoload.php");

app()->before("before");

app()->route("GET", "/", function () {
	$content = template()->render("index.twig");
	response()->raw($content);
});

app()->route("GET", "/commands/migrate", function () {
	$tables = mysql()->column("SHOW TABLES;");
	if (!in_array("migrations", $tables)) {
		mysql()->execute("
			CREATE TABLE `migrations` (
				`id` BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
				`name` VARCHAR(255) NOT NULL,
				`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (`id`),
				UNIQUE (`name`)
			);
		");
	}
	$files = glob(__ROOT__ . "/src/Migrations/*.sql");
	sort($files);
	foreach ($files as $file) {
		$name = basename($file);
		$count = mysql()->value("SELECT COUNT(`id`) FROM `migrations` WHERE `name` = ?;", [$name]);
		if (!$count) {
			mysql()->execute(file_get_contents($file));
			mysql()->insert("INSERT INTO `migrations` (`name`) VALUES (?);", [$name]);
		}
	}
	response()->raw("OK");
});

app()->fallback(function () {
	response()->raw("Not Found", 404);
});

app()->error(function (Throwable $throwable) {
	if (env("DEBUG")) {
		dd($throwable);
	}
	error_log($throwable);
	response()->raw("Internal Server Error", 500);
});

app()->start();
