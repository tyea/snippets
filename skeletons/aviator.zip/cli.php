<?php

$_SERVER["REQUEST_METHOD"] = "GET";
$_SERVER["REQUEST_URI"] = $argv[1] ?? "/";
require __DIR__ . "/public/index.php";
