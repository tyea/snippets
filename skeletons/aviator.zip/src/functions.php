<?php

use Tyea\Aviator\Model;

function model(string $model): Model
{
	$class = "\\Models\\" . $model . "Model";
	if (!class_exists($class)) {
		throw new Exception();
	}
	return new $class();
}

function view(string $template, array $data = [], $code = 200): void
{
	$content = template()->render($template, $data);
	response()->raw($content, $code);
}

function controller(string $controller, $action): callable
{
	$class = "\\Controllers\\" . $controller . "Controller";
	$method = $action . "Action";
	if (!class_exists($class) || !method_exists($class, $method)) {
		throw new Exception();
	}
	return function () use ($class, $method) {
		$callable = [new $class(), $method];
		$args = func_get_args();
		call_user_func_array($callable, $args);
	};
}

function cli(): bool
{
	return PHP_SAPI == "cli";
}
