<?php

namespace Models;

use Tyea\Aviator\Model;

class UserModel extends Model
{
	protected $table = "users";

	protected function selectRowByEmailAddress(string $emailAddress): ?array
	{
		return mysql()->row("SELECT * FROM `users` WHERE `email_address` = ?;", [$emailAddress]);
	}
}
