CREATE TABLE `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
    `email_address` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL,
    `logged_in_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE (`email_address`)
);
