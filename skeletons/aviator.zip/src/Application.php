<?php

class Application
{
	public function before()
	{
		$vars = parse_ini_file(__ROOT__  . "/.env", false, INI_SCANNER_TYPED);
		$_ENV = array_merge($_ENV, $vars);

		$dsn = sprintf(
			"mysql:host=%s;port=%s;dbname=%s;charset=%s",
			env("MYSQL_HOST"),
			env("MYSQL_PORT"),
			env("MYSQL_DATABASE"),
			env("MYSQL_CHARACTER_SET")
		);
		$options = [
			Pdo::ATTR_ERRMODE => Pdo::ERRMODE_EXCEPTION,
			Pdo::ATTR_EMULATE_PREPARES => false,
			Pdo::ATTR_TIMEOUT => 3
		];
		mysql()->configure($dsn, env("MYSQL_USERNAME"), env("MYSQL_PASSWORD"), $options);

		template()->configure(__ROOT__ . "/src/Views");

		if (request()->getContentType() == "json" && request()->getContent() != "") {
			request()->request->replace(request()->toArray());
		}
	}

	public function fallback()
	{
		view("error.twig", ["message" => "Not Found"], 404);
	}

	public function error(Throwable $throwable)
	{
		if (env("DEBUG")) {
			dd($throwable);
		}
		error_log($throwable);
		view("error.twig", ["message" => "Internal Server Error"], 500);
	}
}