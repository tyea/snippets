<?php

namespace Controllers;

class CommandsController
{
	public function migrateAction(): void
	{
		if (!cli()) {
			response()->raw("Forbidden", 403);
		}
		$tables = mysql()->column("SHOW TABLES;");
		if (!in_array("migrations", $tables)) {
			mysql()->execute("
			CREATE TABLE `migrations` (
				`id` BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
				`name` VARCHAR(255) NOT NULL,
				`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (`id`),
				UNIQUE (`name`)
			);
		");
		}
		$files = glob(__ROOT__ . "/src/Migrations/*.sql");
		sort($files);
		foreach ($files as $file) {
			$name = basename($file);
			$count = mysql()->value("SELECT COUNT(`id`) FROM `migrations` WHERE `name` = ?;", [$name]);
			if (!$count) {
				mysql()->execute(file_get_contents($file));
				mysql()->insert("INSERT INTO `migrations` (`name`) VALUES (?);", [$name]);
			}
		}
		response()->raw("OK");
	}
}