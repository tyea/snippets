<?php

namespace Controllers;

class DefaultController
{
	public function indexAction(): void
	{
		view("index.twig");
	}
}